extend("fiskheroes:colossus_xmen");
loadTextures({
    "layer1": "fiskheroes:colossus_comics_layer1",
    "layer2": "fiskheroes:colossus_comics_layer2"
});


       