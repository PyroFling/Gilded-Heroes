extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "ghp:wolverine_comics_layer1",
    "layer2": "ghp:wolverine_comics_layer2",
   
});


       