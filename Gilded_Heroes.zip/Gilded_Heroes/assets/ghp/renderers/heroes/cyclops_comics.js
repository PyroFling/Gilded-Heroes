extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "ghp:cyclops_comics_layer1",
    "layer2": "ghp:cyclops_comics_layer2",
    "overlay": "ghp:cyclops_comics_overlay"
});

var utils = implement("fiskheroes:external/utils");

var overlay;

function initEffects(renderer) {

    overlay = renderer.createEffect("fiskheroes:overlay");
    overlay.texture.set(null, "overlay");

    utils.bindBeam(renderer, "fiskheroes:charged_beam", "ghp:optic_blast", "head", getBeamColor(), [
        { "firstPerson": [0.0, 0.0, 0.0], "offset": [0.0, -3.25, -3.75], "size": [5.5, 1.0] }
    ]).setParticles(renderer.createResource("PARTICLE_EMITTER", "fiskheroes:impact_charged_beam"));
}

function getBeamColor() {
    return 0xE12323;
}

function render(entity, renderLayer, isFirstPersonArm) {
    if (!isFirstPersonArm) {
        if (renderLayer == "HELMET") {
            overlay.opacity = entity.getInterpolatedData("fiskheroes:beam_charge");
            overlay.render();
        }
    }
}
