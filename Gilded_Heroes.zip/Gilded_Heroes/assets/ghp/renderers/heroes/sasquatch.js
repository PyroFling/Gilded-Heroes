extend("fiskheroes:hero_basic");
loadTextures({
    "layer1": "ghp:sasquatch_layer1",
    "layer2": "ghp:sasquatch_layer2",
   
});


       